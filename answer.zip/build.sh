g++ -std=c++17 -g -c lexer.cpp -o lexer.o -O2
g++ -std=c++17 -g -c parser.cpp -o parser.o -O2
g++ -std=c++17 -g -c parserUtil.cpp -o parserUtil.o -O2
g++ -std=c++17 -g -c main.cpp -o main.o -O2

g++ -std=c++17 -g lexer.o parser.o parserUtil.o main.o -o Main -lm